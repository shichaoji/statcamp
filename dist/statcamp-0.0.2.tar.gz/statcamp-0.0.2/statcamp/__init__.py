# coding: utf-8

#import sys
#try:
#    reload(sys)
#    sys.setdefaultencoding("utf-8")
#except:
#    print('python3')

from .base import *

__version__ = '0.1'
__license__ = 'MIT'

__all__ = ['']

def main():
    print 'executing...'
    base_main()

